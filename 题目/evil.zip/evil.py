# coding: utf-8

import base64
import string
import random
import hashlib


def random_str(length=4, chars=string.ascii_lowercase):
    words = ''
    chars_len = len(chars) - 1
    for i in range(length):
        words += chars[random.randint(0, chars_len)]
    return words


def key_crypt(data, key):
    md5 = hashlib.md5()
    md5.update(key.encode())
    key_md5 = md5.hexdigest()
    key_index = 0
    cipher_data = ''
    for i in range(len(data)):
        key_index = 0 if key_index == 32 else key_index
        cipher_data += chr(ord(data[i]) ^ ord(key_md5[key_index]))
    return cipher_data


def encrypt(plain_data, key):
    rnd = random_str(32)
    plain_data_len = len(plain_data)
    rnd_index = 0
    cipher_data = ''
    for i in range(plain_data_len):
        rnd_index = 0 if rnd_index == 32 else rnd_index
        cipher_data += rnd[rnd_index] + chr(ord(plain_data[i]) ^ ord(rnd[rnd_index]))
    return base64.b64encode(key_crypt(cipher_data, key).encode()).decode()


cipher = encrypt('flag{fake_flag}', 'SK1llS_KeY')
with open('enc_flag.txt', 'w') as f:
    f.write(cipher)
